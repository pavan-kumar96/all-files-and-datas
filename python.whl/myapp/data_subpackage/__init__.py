# why is this file required? it's only for example4.py
# that's a shortcoming of importlib.resources
# see https://gitlab.com/python-devs/importlib_resources/issues/58
